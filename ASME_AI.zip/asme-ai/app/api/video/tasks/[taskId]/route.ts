import { NextResponse } from 'next/server';
const API = process.env.AGNES_BASE_URL || 'https://apihub.agnes-ai.com';
const MODEL = 'agnes-video-2.5-flash';
export async function GET(_req: Request, context: { params: Promise<{ taskId: string }> }) {
  const key = process.env.AGNES_API_KEY;
  if (!key) return NextResponse.json({ error: 'Server is not configured with a free provider API key.' }, { status:503 });
  const { taskId } = await context.params;
  if (!/^[\w-]{6,100}$/.test(taskId)) return NextResponse.json({ error:'Invalid video ID.' }, { status:400 });
  try {
    const res = await fetch(`${API}/agnesapi?video_id=${encodeURIComponent(taskId)}&model_name=${encodeURIComponent(MODEL)}`, { headers:{Authorization:`Bearer ${key}`}, cache:'no-store' });
    const data = await res.json().catch(()=>({}));
    if (!res.ok) return NextResponse.json({ error:data?.message || data?.error || `Status request failed (${res.status}).` }, { status:res.status });
    return NextResponse.json({ videoId: data.video_id || taskId, status: data.status, progress: data.progress, videoUrl: data.url || data.video_url || null, error: data.error || data.message || null });
  } catch (e) { return NextResponse.json({ error:e instanceof Error ? e.message : 'Polling failed.' }, { status:500 }); }
}
