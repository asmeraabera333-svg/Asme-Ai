import { NextResponse } from 'next/server';
const API = process.env.AGNES_BASE_URL || 'https://apihub.agnes-ai.com';
const MODEL = 'agnes-video-2.5-flash';
export async function POST(req: Request) {
  const key = process.env.AGNES_API_KEY;
  if (!key) return NextResponse.json({ error: 'Free provider setup needed: add AGNES_API_KEY in server environment settings.' }, { status: 503 });
  try {
    const body = await req.json();
    const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
    const mode = body.mode === 'image' ? 'keyframe' : 'text';
    const seconds = Number(body.duration);
    const ratio = body.ratio;
    if (prompt.length < 5 || prompt.length > 1000) return NextResponse.json({ error: 'Prompt must be 5–1,000 characters.' }, { status: 400 });
    if (![4, 5, 6, 8, 10, 12].includes(seconds)) return NextResponse.json({ error: 'Choose a supported duration between 4 and 12 seconds.' }, { status: 400 });
    if (!['16:9','9:16','1:1','4:3','3:4','21:9'].includes(ratio)) return NextResponse.json({ error: 'Unsupported aspect ratio.' }, { status: 400 });
    const payload: Record<string, unknown> = { model: MODEL, prompt, mode, seconds: String(seconds), size: '720P', aspect_ratio: ratio, n: 1 };
    if (mode === 'keyframe') {
      const frame = body.imageData;
      if (typeof frame !== 'string' || !/^data:image\/(png|jpeg|webp);base64,/i.test(frame)) return NextResponse.json({ error: 'Upload a PNG, JPEG or WebP starting image.' }, { status: 400 });
      if (frame.length > 4_200_000) return NextResponse.json({ error: 'Image too large. Maximum upload size is 3 MB.' }, { status: 413 });
      payload.first_frame = frame;
    }
    const res = await fetch(`${API}/v1/videos`, { method:'POST', headers:{ Authorization:`Bearer ${key}`, 'Content-Type':'application/json' }, body:JSON.stringify(payload) });
    const data = await res.json().catch(()=>({}));
    if (!res.ok) return NextResponse.json({ error: data?.error?.message || data?.message || data?.error || `Free video service error (${res.status}).` }, { status:res.status });
    const videoId = data.video_id || data.id;
    if (!videoId) return NextResponse.json({ error: 'Provider did not return a video ID. Please retry later.' }, { status:502 });
    return NextResponse.json({ videoId, taskId: data.task_id || videoId, model:MODEL, status:data.status || 'submitted' });
  } catch (e) { return NextResponse.json({ error:e instanceof Error ? e.message : 'Unknown generation error.' }, { status:500 }); }
}
