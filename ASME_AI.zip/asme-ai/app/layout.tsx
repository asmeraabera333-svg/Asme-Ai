import type { Metadata } from 'next';
import './styles.css';
export const metadata: Metadata = { title: 'ASME AI', description: 'Create cinematic videos with ASMERA AI' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
