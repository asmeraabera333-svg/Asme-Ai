# ASME AI — Free-first Creator Studio

A Next.js/Vercel starter for ASME AI. Paid Runway integration has been removed. The video tab connects to Agnes AI's `agnes-video-2.5-flash` API, currently documented as a limited-time free promotion for 720P; free access, availability, rate limits, and queues can change. **This is not a guaranteed permanently free service.** Do not use paid models or add billing unless the owner chooses.

## Included features
- Text-to-video and image-to-video request flow using the free promotional Agnes model.
- Asynchronous polling and video preview.
- Local script writer templates (no AI API calls required).
- Captions generated from script punctuation/line breaks (no paid transcription service).
- Browser/device text-to-speech preview using Web Speech `SpeechSynthesis` (voices and Amharic/Oromo availability depend on device/browser; audio is preview playback, not downloaded audio).
- Download script and captions as plain text.
- Responsive mobile-first UI.

## Video API setup
1. Register on the Agnes platform and obtain an API key. Free access can have restrictions and the video queue may be busy.
2. Create `.env.local` based on `.env.example` and set `AGNES_API_KEY`.
3. Do not place API keys in client-side code, GitHub, or `NEXT_PUBLIC_` variables.
4. Install dependencies with `npm install`, then run `npm run dev`.
5. The API route calls `POST https://apihub.agnes-ai.com/v1/videos` with model `agnes-video-2.5-flash`; the status route polls `GET /agnesapi?video_id=...&model_name=agnes-video-2.5-flash`.

## Free tools-only mode
The Script & Voice tools tab works without an API key or video API. It writes a reusable script from simple local templates, formats captions from the script, and previews speech with the device's built-in browser speech engine. It does not claim to generate downloadable voice files or export finished videos.

## Deploy
Push to GitHub and import into Vercel. In Vercel → Project Settings → Environment Variables, add `AGNES_API_KEY` as a server-only secret and redeploy. To use the script/caption/voice-preview features only, no key is needed.

## Limitations & safety
- Agnes API promotional free video is limited/subject to change; users may encounter unavailable queues or rate limits. Confirm model and free status in provider docs before relying on it.
- No auth, database, user quota, rate limiting, or permanent media storage yet. Protect a public deployment from abuse before sharing widely.
- Uploaded image data is sent to the API route as a data URL (max 3 MB); larger uploads need a storage/upload design.
- Browser TTS voice choices are local-device dependent and don't guarantee Amharic/Oromo voices.
- Script generator and caption formatting are offline templates, not generative AI or speech transcription.

## References
- Agnes AI models and API guide: https://github.com/AgnesAI-Labs/skills/tree/main/agnes-ai-models
- Agnes video API documentation: https://wiki.agnes-ai.com/en/docs/agnes-video-25-flash.md
